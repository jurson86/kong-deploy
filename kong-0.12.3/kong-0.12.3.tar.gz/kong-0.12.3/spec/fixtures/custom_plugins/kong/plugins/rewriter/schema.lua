return {
  fields = {
    value = { typ = "string" },
    extra = {
      typ     = "string",
      default = "extra",
    }
  }
}
