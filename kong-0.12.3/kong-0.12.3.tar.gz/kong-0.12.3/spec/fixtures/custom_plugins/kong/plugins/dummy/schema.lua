return {
  fields = {
    resp_header_value = { type = "string", default = "1" },
    append_body = { type = "string" },
  }
}
