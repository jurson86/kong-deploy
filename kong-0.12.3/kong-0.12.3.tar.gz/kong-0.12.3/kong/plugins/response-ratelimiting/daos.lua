return {
  tables = {"response_ratelimiting_metrics"}
}
