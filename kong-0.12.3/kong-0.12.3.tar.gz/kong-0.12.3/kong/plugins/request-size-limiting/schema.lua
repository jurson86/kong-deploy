return {
  fields = {
    allowed_payload_size = { default = 128, type = "number" }
  }
}
