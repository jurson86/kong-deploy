local _M = {
  configuration = nil,
  dao = nil,
  ip = nil,
  dns = nil,
  loaded_plugins = nil,
  worker_events = nil,
}

return _M
